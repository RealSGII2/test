// Requirements
const app = require('../app.js');

module.exports = client => {
    app.logMessage('AICharacter::EndPlay()');
};
